<style scoped>
    div {
      margin-top: 20px;
    }
    span {
      color: #6c6c6c
    }

</style>

<template>
  <div>
    <center><span> Copyright © 2018 See </span> </center>
  </div>
</template>