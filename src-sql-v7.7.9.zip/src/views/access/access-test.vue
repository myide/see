<template>
  <div>
    <Card shadow>
      <p>当前用户的权限值是 0 时，才可以看到这个页面。</p>
    </Card>
  </div>
</template>

<script>
export default {

};
</script>

<style>
  
</style>
